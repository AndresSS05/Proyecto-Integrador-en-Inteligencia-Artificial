# `src/` — Código Fuente Modular

Esta carpeta está reservada para futura refactorización del notebook principal en módulos Python reutilizables.

## Estructura Planificada

```
src/
├── __init__.py
├── data/
│   ├── __init__.py
│   └── loader.py              # Carga del dataset Spider desde HF Hub
│
├── features/
│   ├── __init__.py
│   ├── sql_features.py        # Extracción de features SQL (JOIN, subconsultas, etc.)
│   ├── linguistic_features.py # Features lingüísticas de la pregunta natural
│   └── pipeline.py            # Pipeline de preprocesamiento completo
│
├── models/
│   ├── __init__.py
│   ├── benchmark.py           # Entrenamiento y evaluación comparativa
│   └── fairness.py            # Cálculo de métricas de fairness
│
├── evaluation/
│   ├── __init__.py
│   ├── metrics.py             # Métricas custom (DI Ratio, EO Gap)
│   └── learning_curves.py     # Construcción de curvas de aprendizaje
│
└── visualization/
    ├── __init__.py
    └── plots.py               # Funciones para las 4 figuras del informe
```

## Estado Actual

**Pendiente.** En la versión 1.0.0 el código vive monolíticamente en el notebook `notebooks/01_evaluacion_modelos_spider.ipynb`. La refactorización a módulos está planificada para la versión 2.0.0 (ver `CHANGELOG.md`).

## ¿Quieres Contribuir?

Si deseas colaborar con la refactorización, consulta la guía [`CONTRIBUTING.md`](../CONTRIBUTING.md) en la raíz del repositorio.
